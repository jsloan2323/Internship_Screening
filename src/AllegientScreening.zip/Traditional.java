
public class Traditional extends Courses {
	
	

		public void Traditional(){
			
			
			this.coursename = "Traditional";
			this.max = 30;
		}
		
	}

