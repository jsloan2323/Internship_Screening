
public class Distance_Education extends Courses{
	
	
	
	public void indyStudy(){
		
		this.coursename = "Independent Study";
		this.max = 25;
		
	}
	
public void vidConference(){
		
		this.coursename = "Video Conferencing";
		this.max = 15;
		
	}

}
