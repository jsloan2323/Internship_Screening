
public class Allegient_U_Main {
	
	public void main (String args[]){

	Allegient_University.newCourse("Traditional");
	
	

}
	
}
