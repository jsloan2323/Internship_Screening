
public class Course_Type {

}
