import java.util.*;

public class Allegient_University {
	
	public static void newCourse(String coursename){
		
		Courses course = new Courses();
	}
	

	

}
